package com.tweetapp.application.service;

import java.util.ArrayList;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tweetapp.application.Dao.UserDao;
import com.tweetapp.application.exception.CustomException;
import com.tweetapp.application.model.User;


@Service @Transactional
public class UserServiceImpl implements UserService, UserDetailsService{
	@Autowired
	private UserDao userDao;
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userDao.findByEmail(username);
		if(user == null) {
			logger.info("User not found in Database");
			throw new UsernameNotFoundException("User not found in Database");
		}else {
			
		}
		Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), authorities);
	}
	@Override
	public Map<String , String> saveUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		Map<String , String> response = new HashMap<>();
		try {
			userDao.save(user);
		}catch(DuplicateKeyException exception) {
			throw new CustomException("Email ID already in Use, please enter new email.");
		}
		response.put("StatusCode", "200");
		response.put("Description" , "User registration successful.");
		return response;
	}


	@Override
	public User getUser(String email) {
		return userDao.findByEmail(email);
	}

	@Override
	public List<User> getUsers() {
		return userDao.findAll();
	}
	@Override
	public Map<String, String> updatePassword(User user) {
		Map<String , String> response = new HashMap<>();
		String userName = user.getEmail();
		User user1 = userDao.findByEmail(userName);
		user1.setPassword(passwordEncoder.encode(user.getPassword()));
		userDao.save(user1);
		response.put("StatusCode", "200");
		response.put("User EmailID" ,user.getEmail() );
		response.put("Description" , "password Updated Successfully.");
		return response;
	}

	
}
