export const registrationSuccess = {
    Description: 'User registration successful.', StatusCode: '200'
}
export const registrationEmailInUseErrorResponse = {
    Description: 'Email ID already in Use, please enter new email.', StatusCode: '11000'
}