export const loginSuccessResponse = {
    access_token:
     'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJuZ…jQ3fQ.CwwzVwuYjrBf_nMue3K_AqU3mTvt36pdPdX4rp389Tw',
     code: '200',
     username: 'neeraja.uppalapati@gmail.com'
}
export const loginErrorResponse = {
    code: '404', Description: 'User not found.'
}
