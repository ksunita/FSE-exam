import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { UserServiceService } from 'src/app/Services/user-service.service';
import { loginErrorResponse, loginSuccessResponse } from './user-login.component.spec.util';
import { of } from 'rxjs';
import { UserLoginComponent } from './user-login.component';

describe('UserLoginComponent', () => {
  let component: UserLoginComponent;
  let fixture: ComponentFixture<UserLoginComponent>;
    let service : UserServiceService;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserLoginComponent ],
      imports:[
          HttpClientTestingModule, RouterTestingModule
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserLoginComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(UserServiceService)
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should check whether form is valid', () =>{
      component.loginform.controls.username.setValue('Thirumala.Nizampatnam@gmail.com');
      component.loginform.controls.password.setValue('thirumala');
      fixture.detectChanges();
      expect(component.loginform.valid).toBeTruthy();
  });
  it('should check whether submit is disabled', () =>{
      component.loginform.controls.username.setValue('');
      component.loginform.controls.password.setValue('');
      fixture.detectChanges();
      expect(component.loginform.invalid).toBeTruthy();
  });
  it('on click submit', () => {
    spyOn<any>(service, 'login').and.returnValue(of(loginSuccessResponse));
    spyOn<any>(sessionStorage,'setItem');
    fixture.detectChanges();
    component.login();
    expect(sessionStorage.setItem).toHaveBeenCalled();
  });
  it('should check whetheruser not founsd on click submit ', () =>{
    spyOn<any>(service, 'login').and.returnValue(of(loginErrorResponse));
    fixture.detectChanges();
    component.login();
    expect(component.userNotFound).toBe(true);
  })

});
