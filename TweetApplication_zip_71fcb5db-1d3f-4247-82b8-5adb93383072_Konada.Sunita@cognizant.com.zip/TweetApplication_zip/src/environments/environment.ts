// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  loginUrl : 'http://localhost:8081/login',
  postTweetMsg : 'http://localhost:8081/api/v1.0/tweets/tweet/add',
  getAllTweets: 'http://localhost:8081/api/v1.0/tweets/tweet/all',
  getUser: 'http://localhost:8081/api/v1.0/tweets/user/search',
  likeTweetUrl : 'http://localhost:8081/api/v1.0/tweets/tweet/user/like',
  updateTweetUrl : 'http://localhost:8081/api/v1.0/tweets/tweet/user/update',
  adduser : 'http://localhost:8081/api/v1.0/tweets/register',
  resetPasswordUrl : 'http://localhost:8081/api/v1.0/tweets/user/forgotPassword',
  deleteTweetUrl : 'http://localhost:8081/api/v1.0/tweets/tweet/user/delete',
  replyTweetUrl : 'http://localhost:8081/api/v1.0/tweets/tweet/user/reply',
  userTweetsUrl : 'http://localhost:8081/api/v1.0/tweets/tweet/user'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
